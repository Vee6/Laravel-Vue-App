import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import IndexView from '../views/menu/Index.vue'
import Add from '../views/menu/Add.vue'
import Update from '../views/menu/Update.vue'
import Login from '../views/menu/Login.vue'
import Register from '../views/menu/Register.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/about',
      name: 'about',
      component: () => import('../views/AboutView.vue')
    },
    {
      path: '/menu',
      name: 'menu',
      component: IndexView
    },
    {
      path: '/menu/add',
      name: 'add',
      component: Add
    },
    {
      path: '/menu/:id/update',
      name: 'update',
      component: Update
    },
    {
      path: '/menu/login',
      name: 'login',
      component: Login
    },
    {
      path: '/menu/register',
      name: 'register',
      component: Register
    }
  ]
})

export default router
