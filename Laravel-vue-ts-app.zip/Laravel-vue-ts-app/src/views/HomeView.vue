<template>
  <header>

    <div class="wrapper">
      <nav class="navbar navbar-expand-lg bg-body-tertiary shadow sticky-top">
        <div class="container text-dark">
          <h3>Welcome to Caffei.com</h3>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 float-end">
              <li class="nav-item btn btn-sm btn-outline-primary py-0">
                <RouterLink class="nav-link active" aria-current="page" to="/menu/login">Login</RouterLink>
              </li>
              <li class="nav-item btn btn-sm btn-primary py-0 mx-2">
                <RouterLink class="nav-link text-white" to="/menu/register">Sign Up</RouterLink>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </header>
  <main>
    <div class="container mt-5">
      <h2 class="d-flex justify-content-center text-success">Admin Portal</h2>
    </div>
  </main>

  
  <RouterView />

</template>
