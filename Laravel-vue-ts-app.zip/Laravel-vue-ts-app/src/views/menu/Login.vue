<template>
<header>
    <div class="wrapper">
        <nav class="navbar navbar-expand-lg bg-body-tertiary shadow sticky-top">
        <div class="container text-dark">
            <h3>Welcome to Caffei.com</h3>
        </div>
        </nav>
    </div>
</header>
<main>
<div class="container mt-5">
    <div class="row  ms-auto me-auto" style="width: 800px">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-warning">
                    <h4 class="text-center">Login Account</h4>
                </div>
                <div class="card-body bg-info-subtle">
                    <!-- <ul class="alert alert-warning" v-if="Object.keys(this.errorList).length > 0">
                        <li class="mb-0 ms-3" v-for="(error, index) in this.errorList" :key="index">
                            {{ error }}
                        </li> 
                    </ul> -->
                    <div class="mb-3 d-flex justify-content-center">
                        <label for="">Email : </label>
                        <input type="email" name="email" v-model="model.user.email" class="mx-2"/>
                    </div>
                    <div class="mb-3 d-flex justify-content-center">
                        <label for="">Password : </label>
                        <input type="password" name="password" v-model="model.user.password" class="mx-2"/>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button class="btn btn-primary" type="submit" @click="login">Login</button>
                        <button class="btn btn-secondary mx-3" type="reset"><RouterLink to="/" class="text-decoration-none text-white">Cancel</RouterLink></button>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        Don't have an account? Sign up to
                        <RouterLink to="register" class="mx-2"> register </RouterLink>now!
                    </div>   
                </div>
            </div>
        </div>
    </div>
</div>
</main>


<RouterView />

</template>

<script lang="ts">
import axios from 'axios'
import { defineComponent } from 'vue'

export default defineComponent({
    name: "userLogin",
    data() {
        return{

            // errorList: '',
            model: {
                user: {
                    email: '',
                    password: '',
                }
            }
        }
        
    },
    methods: {

        login() {

            // var errthis = this;
            axios.post('http://127.0.0.1:8000/api/menu/login', this.model.user).then(res => {

                if (res.data.access_token){

                    localStorage.setItem(
                        "blog_token",
                        res.data.access_token
                    )
                    
                    window.location.replace('/menu');

                }

                // console.log(res.data)
                alert(res.data.message);

                this.errorList = '';

            });
            // .catch(function (error) {

            //     if (error.response) {

            //         if(error.response.status == 422){
                        
            //             errthis.errorList = error.response.data.errors;
            //         }


            //     } else if (error.request) {
            //         console.log(error.request);
            //     } else {
            //         console.log('Error', error.message);
            //     }

            // });
        },
    },
})
</script>
