<template>
<header>

    <div class="wrapper">
      <nav class="navbar navbar-expand-lg bg-body-tertiary shadow sticky-top">
        <div class="container text-dark">
          <h3>Welcome to Caffei.com</h3>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <button type="button" @click="logout" class="text-white btn btn-secondary ms-auto mb-2 mb-lg-0 float-end">
                Logout
            </button>
          </div>
        </div>
      </nav>
    </div>
  </header>
  <body>
    <div class="container mt-5">
        <h2 class="d-flex justify-content-center text-success">Caffei's Menu</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h6>Menu
                            <RouterLink to="/menu/add" class="btn btn-outlined-secondary float-end">+ Add</RouterLink>
                        </h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered  table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Item</th>
                                    <th>Price(RM)</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody v-if="this.menu.length > 0">
                                <tr v-for="(menu, index) in this.menu" :key="index">
                                    <td>{{ menu.id }}</td>
                                    <td>{{ menu.item }}</td>
                                    <td>{{ menu.price }}</td>
                                    <td class="d-flex justify-content-center">
                                            <RouterLink :to="{path: '/menu/'+menu.id+'/update'}" class="btn btn-primary mx2">Edit</RouterLink> 
                                            <button type="button" @click="deleteMenu(menu.id)" class="btn btn-danger mx-2">Delete</button>
                                    </td>
                                </tr>
                            </tbody>
                            <tbody v-else>
                                <tr>
                                    <td colspan="4">Loading...</td>
                                </tr>
                            </tbody>
                         </table> 
                    </div>
                </div>
            </div>
        </div>
    </div>
  </body>
<RouterView />

</template>

<script lang="ts">
import { defineComponent } from 'vue'
import axios from 'axios'

export default defineComponent({
    name: 'menu',
    components: {},
    data(){
        return {
            menu: []
        }
    },
    mounted(){
        this.getMenu();
    },
    methods:  {
        getMenu() {
            // const token = localStorage.getItem("blog_token");
            axios.get('http://127.0.0.1:8000/api/menu').then(res => {

                    this.menu = res.data.data
                // console.log(this.menu)
            });
        },

        deleteMenu(menuId){

            
            if (confirm ('Are you sure to delete this menu?')){

                console.log(menuId)

                axios.delete(`http://127.0.0.1:8000/api/menu/${menuId}/delete`).then( res => {

                    alert(res.data.message);
                    this.getMenu();

                })
            }
        },

        logout(){

            axios.get('http://127.0.0.1:8000/api/menu/logout').then(res => {
                window.location.href = 'menu/login'
            })
        }
    },

    created() {

        axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem(`blog_token`);


    }
})
</script>

