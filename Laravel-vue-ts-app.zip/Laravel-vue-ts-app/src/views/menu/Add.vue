<template>
<header>

    <div class="wrapper">
      <nav class="navbar navbar-expand-lg bg-body-tertiary shadow sticky-top">
        <div class="container text-dark">
          <h3>Welcome to Caffei.com</h3>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 float-end">
              <li class="nav-item btn btn-sm btn-outline-primary py-0">
                <RouterLink class="nav-link active" aria-current="page" to="/menu">Menu</RouterLink>
              </li>
              <li class="nav-item btn btn-sm btn-secondary py-0 mx-2">
                <RouterLink class="nav-link text-white" to="/">Logout</RouterLink>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
</header>
<body>
    <div class="container mt-5">
        <h2 class="d-flex justify-content-center text-success">Caffei's Menu</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h6>Add New Menu</h6>
                    </div>
                    <div class="card-body">

                        <!-- <ul class="alert alert-warning" v-if="Object.keys(this.errorList).length > 0">
                            <li class="mb-0 ms-3" v-for="(error, index) in this.errorList" :key="index">
                                {{ error }}
                            </li> 
                        </ul> -->
                        <div class="mb-3">
                            <label for="">Name of the menu: </label>
                            <input type="text" v-model="model.menu.item" class="form-control" />
                        </div>
                        <div class="mb-3">
                            <label for="">Price (RM): </label>
                            <input type="text" v-model="model.menu.price" class="form-control" />
                        </div>
                        <div class="d-flex justify-content-center">
                            <button class="btn btn-success px-2" @click="saveMenu" type="submit" >Add</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</template>

<script lang="ts">
import axios from 'axios'
import { defineComponent } from 'vue'

export default defineComponent({
    name: "menuCreate",
    data() {
        return{

            //errorList: null,
            model: {
                menu: {
                    item: '',
                    price: '',
                }
            }
        }
        
    },
    methods: {

        saveMenu() {

            // var errthis = this;
            axios.post('http://127.0.0.1:8000/api/menu/add', this.model.menu).then(res => {

                console.log(res.data)
                alert(res.data.message);

                this.model.menu = {
                    item: '',
                    price: ''
                }
            });
            // .catch(function (error) {

            //     if (error.response) {

            //         if(error.response.status == 422){
                        
            //             errthis.errorList = error.response.data.errors;
            //         }


            //     } else if (error.request) {
            //         console.log(error.request);
            //     } else {
            //         console.log('Error', error.message);
            //     }

            // });
        }

    },
})
</script>
